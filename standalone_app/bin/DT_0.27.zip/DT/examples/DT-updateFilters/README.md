This app demonstrates how to use `updateFilters()` to update the limits on column filters after changes to the data, without re-rendering the entire table.
